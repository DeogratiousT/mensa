

<?php $__env->startSection('sections'); ?>
    <section>
        <div class="px-4 py-2 my-5 text-center">
            <h1 class="display-5 fw-bold">Edit <?php echo e($product->name); ?></h1>
        </div>            
    </section>

    <section>
        <div class="container col-lg-6 col-md-6 col-sm-6">
            <form action="<?php echo e(route('products.update',$product)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
    
                <div class="form-group mt-4">
                    <label for="name">Name</label>
                    <input class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" type="text" id="name" name="name" value="<?php echo e($product->name); ?>">
                    <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback" role="alert">
                            <?php echo e($errors->first('name')); ?>

                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group mt-4">
                    <label for="category_id">Category</label>
                    <select class="form-control <?php echo e($errors->has('category_id') ? ' is-invalid' : ''); ?>" id="category_id" name="category_id">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php if($category->id == $product->category_id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('category_id')): ?>
                        <span class="invalid-feedback" role="alert">
                            <?php echo e($errors->first('category_id')); ?>

                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group mt-4">
                    <label for="price">Price</label>
                    <input class="form-control <?php echo e($errors->has('price') ? ' is-invalid' : ''); ?>" type="number" id="price" name="price" value="<?php echo e($product->price); ?>">
                    <?php if($errors->has('price')): ?>
                        <span class="invalid-feedback" role="alert">
                            <?php echo e($errors->first('price')); ?>

                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group mt-4">
                    <label for="rating">Rating</label>
                    <input class="form-control <?php echo e($errors->has('rating') ? ' is-invalid' : ''); ?>" type="number" min="1" max="5" id="rating" name="rating" value="<?php echo e($product->rating); ?>">
                    <?php if($errors->has('rating')): ?>
                        <span class="invalid-feedback" role="alert">
                            <?php echo e($errors->first('rating')); ?>

                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group mt-4">
                    <label for="cover_image">Cover Image</label>
                    <img src="<?php echo e(asset('assets/products/cover_images') . '/' . $product->cover_image); ?>" alt="" style="height: 35px; width:35px">
                    <input class="form-control <?php echo e($errors->has('cover_image') ? ' is-invalid' : ''); ?>" type="file" id="cover_image" name="cover_image">
                    <?php if($errors->has('cover_image')): ?>
                        <span class="invalid-feedback" role="alert">
                            <?php echo e($errors->first('cover_image')); ?>

                        </span>
                    <?php endif; ?>
                </div>
    
                <div class="form-group mt-4 text-center">
                    <button class="btn btn-success btn-block" type="submit">
                        <i class="mdi mdi-content-save"></i> Submit
                    </button>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supertenet\mensa\project\resources\views/products/edit.blade.php ENDPATH**/ ?>