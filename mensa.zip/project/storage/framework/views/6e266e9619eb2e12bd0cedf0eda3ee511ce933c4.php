

<?php $__env->startSection('sections'); ?>
    <section>
        <div class="px-4 py-2 my-5 text-center">
            <h1 class="display-5 fw-bold">Create Categories</h1>
        </div>            
    </section>

    <section>
        <div class="container col-lg-6 col-md-6 col-sm-6">
            <form action="<?php echo e(route('categories.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
    
                <div class="form-group mt-4">
                    <label for="name">Name</label>
                    <input class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" type="text" id="name" name="name" value="<?php echo e(old('name')); ?>">
                    <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback" role="alert">
                            <?php echo e($errors->first('name')); ?>

                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group mt-4">
                    <label for="cover_image">Cover Image</label>
                    <input class="form-control <?php echo e($errors->has('cover_image') ? ' is-invalid' : ''); ?>" type="file" id="cover_image" name="cover_image" value="<?php echo e(old('cover_image')); ?>">
                    <?php if($errors->has('cover_image')): ?>
                        <span class="invalid-feedback" role="alert">
                            <?php echo e($errors->first('cover_image')); ?>

                        </span>
                    <?php endif; ?>
                </div>
    
                <div class="form-group mt-4 text-center">
                    <button class="btn btn-success btn-block" type="submit">
                        <i class="mdi mdi-content-save"></i> Submit
                    </button>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supertenet\mensa\project\resources\views/categories/create.blade.php ENDPATH**/ ?>