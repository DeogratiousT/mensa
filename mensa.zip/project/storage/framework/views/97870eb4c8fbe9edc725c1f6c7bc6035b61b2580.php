<?php if(session('status')): ?>
    <div class="alert alert-primary">
        <div class="d-flex flex-column">
            <span><?php echo e(session('status')); ?></span>
        </div>
    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <div class="d-flex flex-column">
            <span><?php echo e(session('success')); ?></span>
        </div>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <div class="d-flex flex-column">
            <span><?php echo e(session('error')); ?></span>
        </div>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\supertenet\mensa\project\resources\views/includes/messages.blade.php ENDPATH**/ ?>