

<?php $__env->startSection('sections'); ?>
    <section>
        <div class="px-4 py-2 my-5 text-center">
            <h1 class="display-5 fw-bold">All Categories</h1>
            <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-outline-success"> <i class="fa-solid fa-plus"></i> Create Category</a>
        </div>            
    </section>

    <section>
        <div class="container col-lg-6 col-md-6 col-sm-6">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Image</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($category->name); ?></td>
                            <td>
                                <img src="<?php echo e(asset('assets/categories/cover_images') . '/' .  $category->cover_image); ?>" style="height:35px; width:35px" alt="">
                            </td>
                            <td>
                                <a href="<?php echo e(route('categories.edit', $category)); ?>" data-toggle="tooltip" data-placement="bottom" title="Edit Category" class="mr-2"><i class="fa-regular fa-pen-to-square"></i></a>

                                <a href="<?php echo e(route('categories.destroy', $category)); ?>" data-toggle="tooltip" data-placement="bottom" title="Delete Category" onclick="event.preventDefault(); document.getElementById('delete-category-<?php echo e($category->id); ?>').submit();"><i class="fa-regular fa-trash-can text-danger"></i></a>

                                <form id="delete-category-<?php echo e($category->id); ?>" action="<?php echo e(route('categories.destroy', $category)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4">No Categories</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
              </table>

              <?php echo e($categories->links()); ?> 

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supertenet\mensa\project\resources\views/categories/index.blade.php ENDPATH**/ ?>