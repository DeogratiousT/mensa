

<?php $__env->startSection('sections'); ?>
    <section>
        <div class="px-4 py-2 my-5 text-center">
            <h1 class="display-5 fw-bold">All Products</h1>
            <a href="<?php echo e(route('products.create')); ?>" class="btn btn-outline-success"><i class="fa-solid fa-plus"></i> Create Product</a>
        </div>            
    </section>

    <section>
        <div class="container col-lg-6 col-md-6 col-sm-6">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Image</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Rating</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($product->name); ?></td>
                            <td>
                                <img src="<?php echo e(asset('assets/products/cover_images') . '/' .  $product->cover_image); ?>" style="height:35px; width:35px" alt="">
                            </td>
                            <td><?php echo e($product->category->name); ?></td>
                            <td><?php echo e($product->price); ?></td>
                            <td><?php echo e($product->rating); ?></td>
                            <td>
                                <a href="<?php echo e(route('products.edit', $product)); ?>" data-toggle="tooltip" data-placement="bottom" title="Edit Product" class="mr-2"><i class="fa-regular fa-pen-to-square"></i></a>

                                <a href="<?php echo e(route('products.destroy', $product)); ?>" data-toggle="tooltip" data-placement="bottom" title="Delete Product" onclick="event.preventDefault(); document.getElementById('delete-product-<?php echo e($product->id); ?>').submit();"><i class="fa-regular fa-trash-can text-danger"></i></a>

                                <form id="delete-product-<?php echo e($product->id); ?>" action="<?php echo e(route('products.destroy', $product)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4">No Products</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
              </table>

              <?php echo e($products->links()); ?> 

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supertenet\mensa\project\resources\views/products/index.blade.php ENDPATH**/ ?>