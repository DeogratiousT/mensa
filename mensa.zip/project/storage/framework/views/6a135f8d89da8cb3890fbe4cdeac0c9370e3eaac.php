

<?php $__env->startSection('sections'); ?>
    <section>
        <div class="px-4 py-2 my-5 text-center">
            <h1 class="display-5 fw-bold">Shop with Us <span><i class="fa-regular fa-face-smile text-warning"></i></span></h1>
            <div class="col-lg-6 mx-auto">
            <p class="lead mb-4">Get quality products at the comfort of your homes</p>
            <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
                <a href="<?php echo e(route('shop')); ?>" class="btn btn-outline-success btn-lg px-4">Go Shopping</a>
            </div>
            </div>
        </div>            
    </section>

    <section>
        <div class="container">
            <h6 class="lead">Latest Products</h6>
            <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-3 row-cols-xl-4 g-4">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col">
                        <div class="card">
                        <img src="<?php echo e(asset('assets/products/cover_images') . '/' . $product->cover_image); ?>" class="card-img-top" alt="" style="width: 100%; height:200px">
                        <div class="card-body">
                            <h5 class="card-title">
                                <a href="<?php echo e(route('products.show', $product)); ?>" class="text-dark" style="text-decoration: none"><?php echo e($product->name); ?></a>
                            </h5>
                            <p>
                                KSH. <?php echo e($product->price); ?>

                                <?php if($product->rating == 1): ?>
                                    <i class="fa-regular fa-star text-info"></i>
                                    <i class="fa-regular fa-star"></i>
                                    <i class="fa-regular fa-star"></i>
                                    <i class="fa-regular fa-star"></i>
                                    <i class="fa-regular fa-star"></i>
                                <?php elseif($product->rating == 2): ?>
                                    <i class="fa-regular fa-star text-info"></i>
                                    <i class="fa-regular fa-star text-info"></i>
                                    <i class="fa-regular fa-star"></i>
                                    <i class="fa-regular fa-star"></i>
                                    <i class="fa-regular fa-star"></i>
                                <?php elseif($product->rating == 3): ?>
                                    <i class="fa-regular fa-star text-info"></i>
                                    <i class="fa-regular fa-star text-info"></i>
                                    <i class="fa-regular fa-star text-info"></i>
                                    <i class="fa-regular fa-star"></i>
                                    <i class="fa-regular fa-star"></i>
                                <?php elseif($product->rating == 4): ?>
                                    <i class="fa-regular fa-star text-info"></i>
                                    <i class="fa-regular fa-star text-info"></i>
                                    <i class="fa-regular fa-star text-info"></i>
                                    <i class="fa-regular fa-star text-info"></i>
                                    <i class="fa-regular fa-star"></i>
                                <?php elseif($product->rating == 5): ?>
                                    <i class="fa-regular fa-star text-info"></i>
                                    <i class="fa-regular fa-star text-info"></i>
                                    <i class="fa-regular fa-star text-info"></i>
                                    <i class="fa-regular fa-star text-info"></i>
                                    <i class="fa-regular fa-star text-info"></i>
                                <?php endif; ?>
                            </p>
                            <button type="button" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#add-to-cart">Add to Cart</button>
                        </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No Records</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Modal -->
        <div id="add-to-cart" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-sm">
                <div class="modal-content modal-filled bg-success">
                    <div class="modal-body p-4">
                        <div class="text-light text-center">
                            <i class="dripicons-checkmark h1"></i>
                            <h4 class="mt-2">Tada!</h4>
                            <p class="mt-3">Added to Cart</p>
                            <button type="button" class="btn btn-light my-2" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal -->
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supertenet\mensa\project\resources\views/index.blade.php ENDPATH**/ ?>